# 主张—证据—材料模型

## 三层对象

```text
Material：PDF、图表、数据、参考文献、代码、SI
Evidence：材料中的可定位事实或观察
Claim：论文主张、结构化转述或个人推论
```

## 约束

- 不能从Material直接跳到结论；
- 必须记录Evidence定位；
- Claim必须注明所有者；
- 推论不能伪装成作者原话；
- 图表证据必须保留条件和外推边界；
- 低置信材料不能升级成高置信结论。

## 证据链最小格式

```text
Claim ID
→ Evidence ID
→ source page/section/figure/table
→ structured explanation
→ boundary
```

## 证据强度

- direct：正文、图表或结论直接支持；
- partial：只能支持部分表述；
- contextual：只能提供背景；
- conflicting：与其他段落或表格冲突；
- unverified：当前无法核验。
