# 全文通读任务合同

## 1. 目的

阅读任务是论文从“已下载”进入“可解释、可核验研究资产”的强制闸门。下载、OCR、摘要阅读、网页检索都不等于通读。

## 2. 创建时机

PDF完成版本核验、页数和SHA-256记录后，必须立即创建唯一任务 `READ-<paper_id>-<version_id>`。在任务创建之前不得生成最终矩阵、主题结论或研究空白。

## 3. 任务字段

```yaml
task_id: READ-P001-v1
paper_id: P001
source_pdf: 05-证据与原始材料/PDF/P001--2024--CryptoFormalEval.pdf
fulltext_path: 05-证据与原始材料/全文提取/P001--page-text.md
version: preprint-2024-11-20
page_count: 14
sha256: "..."
priority: P0
reader_lane: formal-verification
assigned_to: human-or-agent
integrator: human-or-agent
status: queued
stages:
  structure: queued
  theory: queued
  author_reasoning: queued
  method: queued
  experiments: queued
  figures_tables: queued
  conclusions_limits: queued
  synthesis: queued
outputs: []
blocking_reason: null
review_status: pending
```

## 4. 分工原则

可以按章节或论文分配给多个阅读者，但每篇必须指定一个 `integrator`。整合者必须重新通读全文，核对分工结果，处理章节之间的逻辑关系，不能直接拼接分工摘要。

推荐的阅读分工：

1. **结构阅读**：建立章节、研究问题、贡献和结论骨架；
2. **理论阅读**：解释密码学假设、威胁模型、算法或系统基础；
3. **方法阅读**：重建输入—处理—中间状态—输出链；
4. **实验阅读**：核对数据、基线、变量、指标、硬件、预算和失败样例；
5. **证据阅读**：逐项检查图表、公式、附录和结论边界；
6. **整合阅读**：从全文重写深度报告并回填矩阵。

## 5. 完成条件

任务只有在下列条件全部满足后才能标记 `completed`：

- 每个阶段都有阅读记录和产物路径；
- 至少有一个直接 PDF 页码/章节锚点；
- 图表和表格清单已核对；
- 12字段矩阵已从详细报告回填，而不是反向生成详细报告；
- 深度说理报告解释了“为什么从问题走到方法”；
- 至少一名独立复核者检查作者主张、结构化转述和综合推论的边界；
- 所有阻塞原因为空，或明确标记 `needs-review`，不得伪装完成。

## 6. 状态机

```text
queued → reading → structure-read → theory-read → method-read
→ experiment-read → evidence-read → synthesis-read
→ independently-reviewed → completed
```

发生断链、证据不足、章节漏读、结论越界或内容空洞时，状态回退到 `needs-optimization`，并记录根因。
