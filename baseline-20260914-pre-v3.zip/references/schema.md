# Paper Record 2.0 数据模式

## 1. 实体关系

```text
Paper
 ├── ReadingTask
 ├── PaperReport
 ├── Claim
 │    └── Evidence
 ├── Figure/Table
 ├── Dataset/Material
 ├── ReferenceUsage
 ├── TopicRelation
 ├── ResearchGap
 └── ReusableAsset
```

## 2. Paper字段

| 字段 | 必填 | 说明 |
|---|---|---|
| paper_id | 是 | 稳定ID，如P001 |
| zotero_item_id | 是 | Zotero唯一ID |
| title | 是 | 完整题名 |
| short_slug | 是 | 短文件名 |
| year | 是 | 发表或版本年份 |
| version | 是 | 期刊/会议/arXiv版本 |
| source_quality | 是 | peer-reviewed/preprint等 |
| directness | 是 | 与主题的直接关系 |
| source_pdf | 是 | 相对路径 |
| pdf_hash | 是 | SHA-256 |
| fulltext_status | 是 | 全文状态 |
| evidence_status | 是 | 证据状态 |

## 3. ReadingTask字段

```yaml
task_id: READ-P001
paper_id: P001
zotero_item_id: 48
priority: P0
reader_lane: formal-verification
assigned_to: "..."
structure_status: done
theory_status: done
method_status: done
evidence_status: done
synthesis_status: done
status: completed
outputs:
  - 04-论文深度阅读/P001--2024--CryptoFormalEval/01-从零理解.md
  - 04-论文深度阅读/P001--2024--CryptoFormalEval/10-主张—证据链.md
```

## 4. Claim字段

```yaml
claim_id: C-P001-001
paper_id: P001
claim_type: problem|theory|method|data|result|contribution|limitation|conclusion
claim_text: "..."
claim_owner: author|structured-summary|inference
source_evidence: [E-P001-001]
confidence: high|medium|low
external_boundary: "..."
```

## 5. Evidence字段

```yaml
evidence_id: E-P001-001
paper_id: P001
material_type: body|figure|table|formula|dataset|reference|SI|code|conclusion
source_path: "..."
source_page: "PDF p.7"
source_section: "4.2 Results"
source_locator: "Figure 2"
quote_or_observation: "..."
used_for: [C-P001-001]
matrix_fields: [F08,F10]
evidence_strength: direct|partial|contextual
usage_status: core|method|result|limitation|background|unused|needs-review
external_boundary: "..."
```

## 6. FigureEvidence字段

```yaml
figure_evidence_id: FIG-P001-01
paper_id: P001
figure_id: "Figure 1"
asset_path: "05-证据与原始材料/图表/P001--2024--CryptoFormalEval/P001--FIG-01--system-overview.png"
card_path: ".../P001--FIG-01--evidence.md"
source_page: "PDF p.4"
caption: "..."
variables: "..."
comparisons: "..."
conditions: "..."
key_observation: "..."
supports_claims: [C-P001-002]
supports_fields: [F06]
not_supported: "不能仅凭流程图判断性能或安全性"
image_hash: "sha256:..."
render_status: rendered|failed|needs-review
```

## 7. MaterialUsage字段

```yaml
material_usage_id: MU-P001-001
paper_id: P001
material_type: reference|dataset|figure|table|SI|code
material_path: "..."
usage_status: core|method|result|limitation|background|unused|needs-review
used_in_note: "..."
used_in_report: "..."
linked_claims: [C-P001-001]
source_locator: "..."
review_status: verified|pending
```

## 8. ResearchGap字段

```yaml
gap_id: G01
title: "..."
source_papers: [P001,P007,P009]
evidence_ids: [E-P001-014]
author_stated_limitations: "..."
synthesis_inference: "..."
research_question: "..."
hypothesis: "..."
data: "..."
independent_variables: []
dependent_variables: []
baselines: []
metrics: []
risks: []
expected_contribution: "..."
```
