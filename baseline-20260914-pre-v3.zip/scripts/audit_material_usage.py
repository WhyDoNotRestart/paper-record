#!/usr/bin/env python3
"""Audit material usage using the explicit Material ledger, with file and consumer checks."""
from __future__ import annotations
import argparse,csv,json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--out'); args=ap.parse_args(); root=Path(args.root).resolve()
    ledger=root/'01-批次与审计'/'材料使用审计.csv'
    if not ledger.exists():
        result={'material_count':0,'used_count':0,'unlinked':[],'invalid_records':[],'ledger_missing':True,'passed':False}
    else:
        with ledger.open('r',encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
        missing=[]; invalid=[]; unused=[]
        for r in rows:
            rel=r.get('material_path') or r.get('path') or ''
            p=root/rel
            if not p.is_file(): missing.append({'material_id':r.get('material_id'),'material_path':rel})
            status=(r.get('usage_status') or '').strip()
            consumers=r.get('consumer_count') or r.get('used_in_note') or ''
            claims=r.get('semantic_provenance_count') or r.get('used_in_claim') or r.get('used_in_matrix_field') or ''
            if not status or not consumers or not claims: invalid.append({'material_id':r.get('material_id'),'reason':'missing usage_status/consumer/provenance fields'})
            if status in {'unused','unused-or-unlinked','仅归档未使用','低置信待复核'}: unused.append(r)
        used=len(rows)-len(unused)
        result={'material_count':len(rows),'used_count':used,'unlinked':missing,'unused_or_review':unused,'invalid_records':invalid,'ledger':'材料使用审计.csv','passed':not missing and not invalid}
    out=Path(args.out) if args.out else root/'01-批次与审计/材料使用审计.json'; out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps({'material_count':result['material_count'],'used_count':result['used_count'],'unlinked_count':len(result['unlinked']),'invalid_count':len(result.get('invalid_records',[])),'passed':result['passed']},ensure_ascii=False))
if __name__=='__main__': main()
