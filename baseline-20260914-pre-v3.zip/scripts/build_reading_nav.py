#!/usr/bin/env python3
"""Build the root reading navigation from Paper Record paper notes."""
from __future__ import annotations
import argparse, re, json
from datetime import datetime, timezone, timedelta
from pathlib import Path

def fm(text: str, key: str, default: str = "未核验") -> str:
    m = re.search(rf"(?m)^{re.escape(key)}:\s*[\"']?([^\"'\n]+)", text)
    return m.group(1).strip() if m else default

def first_bullet(text: str, labels: list[str]) -> str:
    """Extract a labelled bullet from any numbered or unnumbered section."""
    label_re = "|".join(re.escape(label) for label in labels)
    m = re.search(rf"(?ms)^##(?:\s+\d+[.]?)?\s*[^\n]*?(?:{label_re})[^\n]*\n(.*?)(?=^##\s|\Z)", text)
    if not m:
        # Some generated notes put all key points under the 3-minute section.
        m = re.search(r"(?ms)^##\s*0[.]\s*三分钟速读\s*\n(.*?)(?=^##\s|\Z)", text)
    if not m: return "未填写"
    for line in m.group(1).splitlines():
        line=line.strip()
        if line.startswith("-") and (":" in line or "：" in line):
            separator = "：" if "：" in line else ":"
            value=line.split(separator,1)[1].strip()
            value=re.sub(r"^\*+|\*+$", "", value).strip()
            if value: return value.replace("|", "\\|")
    return "未填写"

def main() -> int:
    ap=argparse.ArgumentParser(description="生成根目录论文阅读导航")
    ap.add_argument("--root", required=True)
    args=ap.parse_args(); root=Path(args.root).expanduser().resolve()
    notes=sorted((root/"04-论文笔记").rglob("*.md")) if (root/"04-论文笔记").exists() else []
    rows=[]
    for p in notes:
        t=p.read_text(encoding="utf-8", errors="replace")
        if fm(t,"record_type","") != "paper": continue
        title=fm(t,"title",p.stem); priority=fm(t,"reading_priority", "常规")
        conclusion=first_bullet(t,["主要发现与结论", "结论", "主要结果"])
        question=first_bullet(t,["研究问题", "核心问题"])
        level=fm(t,"completion_level"); scope=fm(t,"evidence_scope")
        link=p.relative_to(root).with_suffix("").as_posix()
        entry=f"[[{link}#主要发现与结论|进入论文]]"
        rows.append((priority,title,conclusion, f"{level} / {scope}", entry, question, link))
    rows.sort(key=lambda x: (x[0] != "优先", x[1]))
    nav=root/"00-论文阅读导航.md"
    auxiliary=root/"00-其他资料索引.md"
    lines=["---","record_type: reading-navigation","title: 论文阅读导航","---","","# 论文阅读导航","","> **日常阅读入口**：先看本页。论文的重要问题、结论、证据等级和直达链接集中在下面；完整笔记、附件和技术细节请看 [[00-其他资料索引]]。","","## 阅读顺序","","1. 先按“优先级”选择论文。","2. 点击“进入论文”直接跳到该论文的“主要发现与结论”。","3. 需要核对证据时，再查看论文笔记中的原文定位、图表卡和附件链接。","","## 论文总览","","| 优先级 | 论文 | 一句话结论 | 证据等级 | 重点入口 |","|---|---|---|---|---|"]
    if rows:
        lines += [f"| {a} | {b} | {c} | {d} | {e} |" for a,b,c,d,e,_,_ in rows]
    else: lines.append("| 待读 | 尚未生成论文条目 | — | — | — |")
    lines += ["","## 研究问题速查","","| 论文 | 研究问题 | 论文笔记 |","|---|---|---|"]
    if rows: lines += [f"| {b} | {f} | [[{g}]] |" for _,b,_,_,_,f,g in rows]
    else: lines.append("| — | — | — |")
    lines += ["","## 横向阅读入口","","- [[01-精华论文]]：论文矩阵、APA和批量索引","- [[02-研究主题]]：分类与推荐阅读路径","- [[03-研究空白与可复用资产/研究空白]]：研究空白、局限和机会","- [[03-研究空白与可复用资产/可复用科研资产]]：方法、指标、数据和代码","- [[00-其他资料索引]]：其余资料、附件和系统文件"]
    nav.write_text("\n".join(lines)+"\n", encoding="utf-8")
    if not auxiliary.exists():
        auxiliary.write_text("\n".join([
            "---", "record_type: auxiliary-materials-index", "title: 其他资料索引", "---", "",
            "# 其他资料索引", "", "> 日常阅读请返回 [[00-论文阅读导航]]。本页集中放不需要每日直接阅读的资料。", "",
            "## 原始资料与附件", "", "- [[99-佐证资料/原始论文]]：PDF、SI、原始图表", "- [[99-佐证资料/图表与证据卡]]：图表裁剪图和证据卡", "",
            "## 结构化资料", "", "- [[01-精华论文]]：矩阵、APA和批量索引", "- [[03-研究空白与可复用资产/概念与术语]]：概念、算法、指标和数据集卡", "- [[99-佐证资料/参考文献]]：BibTeX与引用溯源", "",
            "## 系统与归档", "", "- [[00-系统说明]]：状态、验收报告和文件清单", "- [[99-佐证资料/旧版归档]]：历史版本，仅用于追溯", "- [[99-待人工复核]]：需要人工确认的内容", ""
        ])+"\n", encoding="utf-8")
    # Keep the global manifest and classification ledger in sync immediately
    # after updating the root navigation file.
    rel_nav = nav.relative_to(root).as_posix()
    manifest = root / "00-系统说明" / "paper-record-manifest.json"
    batch_id = fm(nav.read_text(encoding="utf-8"), "record_batch", "unknown")
    if manifest.exists():
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            data = {}
        data.setdefault("schema_version", 1)
        data.setdefault("skill", "papaer-record")
        data.setdefault("root", str(root))
        data.setdefault("batches", [])
        data.setdefault("navigation", {})
        data["navigation"].update({"path": rel_nav, "paper_count": len(rows), "updated_at": datetime.now(timezone(timedelta(hours=8))).isoformat()})
        manifest.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    ledger = root / "00-系统说明" / "文件分类清单.md"
    if ledger.exists():
        text = ledger.read_text(encoding="utf-8")
        rows_to_add = []
        if not any(line.startswith(f"| {rel_nav} |") for line in text.splitlines()):
            rows_to_add.append(f"| {rel_nav} | 阅读导航 | 日常论文阅读入口 | 论文知识库 | 已更新 | {batch_id} |\n")
        for paper_path in notes:
            rel_paper = paper_path.relative_to(root).as_posix()
            if not any(line.startswith(f"| {rel_paper} |") for line in text.splitlines()):
                rows_to_add.append(f"| {rel_paper} | 单篇论文深度笔记 | 导航入口引用的论文重点笔记 | 论文知识库 | 已发现 | {batch_id} |\n")
        if rows_to_add:
            with ledger.open("a", encoding="utf-8") as fh:
                fh.writelines(rows_to_add)
    print(f"updated {nav} ({len(rows)} papers)"); return 0
if __name__ == "__main__": raise SystemExit(main())
