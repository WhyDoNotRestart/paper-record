#!/usr/bin/env python3
"""Check active output filenames and links obey stable-ID policy."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); args=ap.parse_args(); root=Path(args.root).resolve(); bad=[]
 for p in root.rglob('*'):
  if not p.is_file() or '99-原始归档' in p.parts: continue
  # Human-facing paper/material files use stable IDs; machine ledgers and
  # workbook inspection artifacts may retain descriptive names.
  rel=p.relative_to(root).as_posix()
  machine = p.suffix.lower() in {'.jsonl','.ndjson','.pyc'} or p.name.endswith('.inspect.ndjson')
  paper_material = any(part in {'04-论文深度阅读','05-证据与原始材料','02-论文索引','03-主题研究地图','07-研究空白与机会','08-可复用科研资产'} for part in p.relative_to(root).parts)
  if paper_material and len(p.name)>140: bad.append(rel+':name-too-long')
  if paper_material and any(ord(c)>127 for c in p.name) and p.suffix.lower() not in {'.md','.html','.json','.csv','.xlsx','.png','.pdf'}: bad.append(rel+':unsupported-unicode-extension')
  if not machine and not paper_material and len(p.name)>180: bad.append(rel+':name-too-long')
 print(json.dumps({'passed':not bad,'bad_count':len(bad),'bad':bad[:100]},ensure_ascii=False)); return 0 if not bad else 1
if __name__=='__main__': raise SystemExit(main())
