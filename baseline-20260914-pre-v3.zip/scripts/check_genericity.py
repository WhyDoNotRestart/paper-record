#!/usr/bin/env python3
"""Detect meaningful repeated prose across paper reports while ignoring contract boilerplate."""
from __future__ import annotations
import argparse
import collections
import json
import re
from pathlib import Path

IGNORE_PHRASES = [
    "本报告基于全文", "不能因为标题含有", "不能外推到所有模型",
    "任何横向结论都必须回到", "作者支持该方法/基准在明确条件下可行",
    "用于核对研究对象、方法流程、实验结果或局限",
    "优势来自上述具体方法/系统设计，不能与其他论文",
    "作者使用人工真值、公开基准、验证器、专家或明文/基线对照",
    "代码、补充材料和完整数据", "12字段矩阵和Claim/Evidence绑定",
    "跨章节或跨论文得出的研究判断", "这份报告回答“作者为什么这样做",
    "下面列出本论文已提取的图表证据卡", "参考文献总览",
    "references-master.csv", "references-occurrence.csv", "references.bib",
    "references.xlsx", "数据材料总览", "不能脱离样本、模型、硬件、参数和安全假设外推",
    "不能把受控基准写成现实世界全面能力", "能说的最小结论", "不能直接说的内容",
    "不能将本文结果直接外推", "全文证据支持的是在给定数据、模型、工具、硬件、协议、轮数、密钥和预算下的结果",
    "准确率、EM、BLEU、F1、成功率、延迟、加速比、通信量和安全证明状态测量不同问题",
    "只有当结果和研究问题使用同一对象、同一成功判据和同一实验条件时",
    "实验不是为了证明“系统运行过”", "实验数字和复现限制见",
    "方法有效的原因必须与理论假设和实验变量对应", "本文不是孤立地提出一个新模型",
    "若输入信息、数据分布、工具反馈、密码实现、硬件、密钥条件或威胁模型发生变化",
    "论文的研究对象必须与结论的范围一致", "这条链条的关键不是“用了AI”",
    "这篇论文最适合被放在研究链条的特定位置", "需要同时记录作者报告的失败案例",
    "需要明确攻击者拥有的输入、工具、反馈、随机性和计算预算", "本论文的关键对象是“",
]

def strip_frontmatter(text: str) -> str:
    if text.startswith("---"):
        parts = text.split("---", 2)
        return parts[2] if len(parts) >= 3 else text
    return text

def keep(line: str):
    s = re.sub(r"\s+", " ", line.strip())
    if len(s) < 55 or len(s) > 300:
        return None
    if s.startswith(("```", "|", "#", "- [", "* [", ">")):
        return None
    if "](../../" in s or "](../" in s:
        return None
    if any(phrase in s for phrase in IGNORE_PHRASES):
        return None
    return s

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True)
    ap.add_argument("--out")
    args = ap.parse_args()
    root = Path(args.root).resolve()
    docs = []
    for d in sorted((root / "04-论文深度阅读").iterdir()):
        if not d.is_dir():
            continue
        for name in [
            "01-从零理解.md", "02-理论基础.md", "03-作者思路与方法.md",
            "04-实验与结果.md", "05-图表逐项解读.md", "06-结论、局限与外推边界.md",
            "11-深度说理报告.md",
        ]:
            p = d / name
            if p.exists():
                docs.append(p)
    counts = collections.defaultdict(set)
    for p in docs:
        text = strip_frontmatter(p.read_text(encoding="utf-8", errors="replace"))
        for line in text.splitlines():
            s = keep(line)
            if s:
                counts[s].add(p.parent.name)
    repeated = [
        {"text": text, "document_count": len(dirs), "documents": sorted(dirs)}
        for text, dirs in counts.items() if len(dirs) >= 4
    ]
    repeated.sort(key=lambda x: (-x["document_count"], x["text"]))
    result = {"document_count": len(docs), "repeated_boilerplate": repeated, "passed": len(repeated) < 10}
    out = Path(args.out) if args.out else root / "01-批次与审计/模板化风险审计.json"
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"passed": result["passed"], "repeated_count": len(repeated)}, ensure_ascii=False))

if __name__ == "__main__":
    main()
