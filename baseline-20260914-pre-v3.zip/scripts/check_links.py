#!/usr/bin/env python3
"""Audit Markdown/Obsidian/HTML links against active files and renderable targets."""
from __future__ import annotations
import argparse,re,json
from pathlib import Path
WIKILINK=re.compile(r'!?(?<!\!)\[\[([^]#|]+)(?:#[^]|]+)?(?:\|[^]]+)?\]\]')
MDLINK=re.compile(r'!?(?<!\!)\[([^]]*)\]\(([^)]+)\)')
IMAGE=re.compile(r'!\[[^]]*\]\(([^)]+)\)')

def is_active(path,root): return '99-原始归档' not in path.relative_to(root).parts

def resolve(src,target,root):
    target=target.strip().strip('<>').split('#',1)[0].split('?',1)[0]
    if not target or target.startswith(('http://','https://','mailto:','data:')): return None
    if target.startswith('file:///'): target=target[8:]
    if target.startswith('/') or (len(target)>2 and target[1]==':'): return Path(target)
    return (src.parent/target).resolve()

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--out'); args=ap.parse_args(); root=Path(args.root).resolve(); rows=[]
    for src in root.rglob('*'):
        if not src.is_file() or src.suffix.lower() not in {'.md','.html'} or not is_active(src,root): continue
        text=src.read_text(encoding='utf-8',errors='replace')
        for m in WIKILINK.finditer(text):
            target=m.group(1).strip(); p=resolve(src,target,root); rows.append({'source':src.relative_to(root).as_posix(),'syntax':'wikilink','target':target,'resolved':p.relative_to(root).as_posix() if p and p.is_relative_to(root) else str(p) if p else '','exists':bool(p and p.is_file()),'is_directory':bool(p and p.is_dir())})
        for m in MDLINK.finditer(text):
            target=m.group(2).strip(); p=resolve(src,target,root); rows.append({'source':src.relative_to(root).as_posix(),'syntax':'markdown','target':target,'resolved':p.relative_to(root).as_posix() if p and p.is_relative_to(root) else str(p) if p else '','exists':bool(p and p.is_file()),'is_directory':bool(p and p.is_dir())})
        for m in IMAGE.finditer(text):
            target=m.group(1).strip(); p=resolve(src,target,root); rows.append({'source':src.relative_to(root).as_posix(),'syntax':'image','target':target,'resolved':p.relative_to(root).as_posix() if p and p.is_relative_to(root) else str(p) if p else '','exists':bool(p and p.is_file()),'is_directory':bool(p and p.is_dir())})
    result={'root':str(root),'link_count':len(rows),'broken':[r for r in rows if not r['exists'] or r['is_directory']],'directory_targets':[r for r in rows if r['is_directory']],'rows':rows,'excluded':['99-原始归档']}
    out=Path(args.out) if args.out else root/'01-批次与审计/链接渲染审计.json'; out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps({'passed':not result['broken'],'link_count':len(rows),'broken_count':len(result['broken']),'directory_targets':len(result['directory_targets'])},ensure_ascii=False))
if __name__=='__main__': main()
