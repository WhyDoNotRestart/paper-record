#!/usr/bin/env python3
"""Check all 12 matrix fields have an answer, evidence anchor, and boundary."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
FIELDS=['研究类型','研究问题','研究主题','研究目的与核心问题','研究对象与应用场景','研究方法/技术路径','数据与材料来源','主要发现/关键结果','创新点/贡献','结论摘录','实际意义/应用价值','关键词标签']
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--out'); args=ap.parse_args(); root=Path(args.root).resolve(); rows=[]
 for d in sorted((root/'04-论文深度阅读').iterdir()):
  if not d.is_dir(): continue
  p=d/'09-12字段证据矩阵.md'; issues=[]; t=p.read_text(encoding='utf-8',errors='replace') if p.exists() else ''
  for idx,f in enumerate(FIELDS,1):
   pat=rf'(?s)(?:^###?\s*{idx}[.、]\s*{re.escape(f)}|\|\s*F{idx:02d}\s*\|[^\n]*\|\s*{re.escape(f)})'
   if not re.search(pat,t,re.M): issues.append(f'F{idx:02d}:missing-section')
  if t.count('证据')<12: issues.append('evidence-markers<12')
  if not re.search(r'不能推出|外推边界|适用条件',t): issues.append('missing-boundary')
  if len(t)<5000: issues.append('chars<5000')
  rows.append({'paper_id':d.name.split('--',1)[0],'chars':len(t),'issues':issues,'passed':not issues})
 out=Path(args.out) if args.out else root/'01-批次与审计/矩阵字段丰富度验收.json'; out.write_text(json.dumps({'paper_count':len(rows),'passed':all(x['passed'] for x in rows),'rows':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps({'passed':all(x['passed'] for x in rows),'paper_count':len(rows),'failed':sum(not x['passed'] for x in rows)},ensure_ascii=False)); return 0 if all(x['passed'] for x in rows) else 1
if __name__=='__main__': raise SystemExit(main())
