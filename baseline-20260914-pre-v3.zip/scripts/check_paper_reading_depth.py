#!/usr/bin/env python3
"""Evidence-aware audit of per-paper deep-reading reports."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
REQUIRED=['00-论文入口.md','01-从零理解.md','02-理论基础.md','03-作者思路与方法.md','04-实验与结果.md','05-图表逐项解读.md','06-结论、局限与外推边界.md','07-参考文献使用说明.md','08-数据、代码与复现清单.md','09-12字段证据矩阵.md','10-主张—证据链.md','11-深度说理报告.md']
# Each requirement accepts related Chinese labels but still requires real body text.
MARKER_GROUPS={
 'source_evidence':['原文证据','全文证据','证据锚点','页码证据','章节证据'],
 'restatement':['结构化转述','论文转述','作者明确说明','原文要点'],
 'inference':['本次推论','综合推论','我的判断','基于证据的判断'],
 'research_question':['研究问题','核心问题','研究目的'],
 'theory':['理论基础','密码学基础','形式化基础','技术背景'],
 'author_idea':['作者思路','核心思路','设计逻辑','方法概览'],
 'input':['输入','任务输入','数据输入','协议输入'],
 'output':['输出','任务输出','攻击输出','模型输出','验证输出'],
 'experiment':['实验条件','实验设置','实验设计','评测设置'],
 'numbers':['关键数值','关键结果','定量结果','结果数字','指标结果'],
 'negative_boundary':['不能推出','外推边界','适用边界','局限','不应外推'],
 'claim':['Claim','主张—证据','主张ID','C-P'],
 'evidence':['Evidence','证据ID','E-P','证据卡'],
}

def has_any(text, terms): return any(t in text for t in terms)
def count_concrete_anchors(text):
    pages=len(re.findall(r'(?:p\.?|page|页|第)\s*\d+',text,re.I))
    figs=len(re.findall(r'(?:Figure|Fig\.?|Table|图|表)\s*[-#]?\s*\d+',text,re.I))
    nums=len(re.findall(r'(?<![A-Za-z])(?:\d{1,3}(?:,\d{3})+|\d+(?:\.\d+)?\s*(?:%|ms|s|×|倍|轮|条|个|次|GB|KB|bit|bits|token|tokens|epoch|层|级))',text,re.I))
    return pages,figs,nums

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--out'); args=ap.parse_args(); root=Path(args.root).resolve(); base=root/'04-论文深度阅读'; rows=[]
    dirs=sorted(x for x in base.iterdir() if x.is_dir())
    for d in dirs:
        files={p.name:p for p in d.glob('*.md')}
        missing=[x for x in REQUIRED if x not in files]
        contents={name:p.read_text(encoding='utf-8',errors='replace') for name,p in files.items()}
        text='\n'.join(contents.values())
        missing_groups=[k for k,v in MARKER_GROUPS.items() if not has_any(text,v)]
        pages,figs,nums=count_concrete_anchors(text)
        paper_id=d.name.split('--',1)[0]
        custom=paper_id in text and d.name.split('--')[-1].lower() in text.lower()
        link_count=len(re.findall(r'!?\[[^\]]*\]\([^)]*\)|\[\[[^]]+\]\]',text))
        short_files=[name for name in REQUIRED if name in contents and len(contents[name].strip())<350]
        passed=(not missing and len(text)>8000 and len(missing_groups)<=1 and pages>=3 and figs>=1 and nums>=3 and custom and link_count>=8 and not short_files)
        rows.append({'paper_dir':d.relative_to(root).as_posix(),'paper_id':paper_id,'missing_files':missing,'missing_groups':missing_groups,'short_files':short_files,'chars':len(text),'page_anchors':pages,'figure_table_anchors':figs,'numeric_anchors':nums,'custom_paper_content':custom,'link_count':link_count,'passed':passed})
    result={'paper_count':len(rows),'passed':all(r['passed'] for r in rows),'rows':rows}
    out=Path(args.out) if args.out else root/'01-批次与审计/深度阅读验收.json'; out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps({'passed':result['passed'],'paper_count':len(rows),'failed':sum(not r['passed'] for r in rows)},ensure_ascii=False))
if __name__=='__main__': main()

