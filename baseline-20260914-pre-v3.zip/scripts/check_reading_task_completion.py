#!/usr/bin/env python3
"""Validate that every paper has a real reading task and completed stage evidence."""
from __future__ import annotations
import argparse,csv,json,re
from pathlib import Path

STAGES=['结构','理论','作者思路','方法','实验','图表与公式','结论与局限','综合整合']
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--out'); args=ap.parse_args(); root=Path(args.root).resolve(); td=root/'01-批次与审计/reading-tasks'; rows=[]
 for p in sorted((root/'04-论文深度阅读').iterdir()):
  if not p.is_dir(): continue
  pid=p.name.split('--',1)[0]; task=td/f'READ-{pid}-v1.md'; issues=[]
  if not task.exists(): issues.append('missing-task')
  else:
   t=task.read_text(encoding='utf-8',errors='replace')
   for stage in STAGES:
    line=next((x for x in t.splitlines() if x.startswith('| '+stage+' |')), '')
    if not line:
     issues.append('missing-stage:'+stage); continue
    cells=[c.strip() for c in line.strip().strip('|').split('|')]
    status=cells[1] if len(cells)>1 else ''
    artifact=cells[2] if len(cells)>2 else ''
    if status.lower() not in {'done','completed','complete','finished','已完成','完成'}:
     issues.append('stage-not-complete:'+stage+':'+(status or 'blank'))
    if not artifact or artifact in {'—','-','待补'}:
     issues.append('stage-missing-output:'+stage)
   if not re.search(r'(?m)^- 全文整合负责人：\s*(?!pending\s*$|待分配\s*$)',t): issues.append('missing-integrator')
   if not re.search(r'全文证据|PDF\s*p\.?\d+|第\s*\d+\s*页|Figure|Table',t,re.I): issues.append('missing-evidence-log')
  rows.append({'paper_id':pid,'task_path':task.relative_to(root).as_posix() if task.exists() else None,'issues':issues,'passed':not issues})
 out=Path(args.out) if args.out else root/'01-批次与审计/通读任务验收.json'; out.write_text(json.dumps({'paper_count':len(rows),'passed':all(x['passed'] for x in rows),'rows':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps({'passed':all(x['passed'] for x in rows),'paper_count':len(rows),'failed':sum(not x['passed'] for x in rows)},ensure_ascii=False)); return 0 if all(x['passed'] for x in rows) else 1
if __name__=='__main__': raise SystemExit(main())
