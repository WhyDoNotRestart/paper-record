#!/usr/bin/env python3
"""Semantic-depth lint: catches summary-like reports and weak evidence contracts."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path

FILES=['01-从零理解.md','02-理论基础.md','03-作者思路与方法.md','04-实验与结果.md','05-图表逐项解读.md','06-结论、局限与外推边界.md','07-参考文献使用说明.md','08-数据、代码与复现清单.md','09-12字段证据矩阵.md','10-主张—证据链.md','11-深度说理报告.md']
MIN={'01-从零理解.md':1200,'02-理论基础.md':1600,'03-作者思路与方法.md':2200,'04-实验与结果.md':2200,'05-图表逐项解读.md':1200,'06-结论、局限与外推边界.md':1500,'07-参考文献使用说明.md':1000,'08-数据、代码与复现清单.md':1000,'09-12字段证据矩阵.md':5000,'10-主张—证据链.md':2500,'11-深度说理报告.md':5000}
BAN=['采用某算法，效果较好','使用实验验证了方法有效','具有理论、方法和实践意义','见论文','详见实验部分','输入/模型/工具/指标/结论']
MARK=['原文证据','结构化转述','本次推论','不能推出','外推边界','局限']
def anchors(t): return len(re.findall(r'(?:PDF\s*p\.?|page\s*|第\s*)\d+',t,re.I))+len(re.findall(r'(?:Figure|Fig\.?|Table|图|表)\s*[-#]?\s*\d+',t,re.I))
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--out'); args=ap.parse_args(); root=Path(args.root).resolve(); rows=[]
 for d in sorted((root/'04-论文深度阅读').iterdir()):
  if not d.is_dir(): continue
  issues=[]; fs={x.name:x for x in d.glob('*.md')}
  text='\n'.join(x.read_text(encoding='utf-8',errors='replace') for x in fs.values())
  if len(text)<30000: issues.append(f'total-chars<{30000}:{len(text)}')
  for fn in FILES:
   if fn not in fs: issues.append('missing:'+fn); continue
   t=fs[fn].read_text(encoding='utf-8',errors='replace'); n=len(t)
   if n<MIN[fn]: issues.append(f'{fn}:chars<{MIN[fn]}:{n}')
   if fn in {'02-理论基础.md','03-作者思路与方法.md','04-实验与结果.md','06-结论、局限与外推边界.md','11-深度说理报告.md'}:
    miss=[m for m in MARK if m not in t]
    if len(miss)>2: issues.append(fn+':missing-markers:'+','.join(miss))
   if fn=='09-12字段证据矩阵.md':
    for i in range(1,13):
     if f'F{i:02d}' not in t and not re.search(rf'(?m)^#{2,4}\s*{i}[.、]',t): issues.append(f'matrix-field-missing:{i}')
   if fn in {'01-从零理解.md','02-理论基础.md','03-作者思路与方法.md','04-实验与结果.md','06-结论、局限与外推边界.md','11-深度说理报告.md'} and anchors(t)<3: issues.append(fn+':anchors<3')
   for ban in BAN:
    if ban in t: issues.append(fn+':banned-template:'+ban)
  # repeated long paragraphs across files are suspicious
  paras=[]
  for fn,p in fs.items():
   for para in re.split(r'\n\s*\n',p.read_text(encoding='utf-8',errors='replace')):
    para=re.sub(r'\s+',' ',para).strip()
    if len(para)>160: paras.append((fn,para))
  reps=[]
  for i,(f1,a) in enumerate(paras):
   for f2,b in paras[i+1:]:
    if a==b: reps.append(f'{f1}=={f2}')
  if reps: issues.append('repeated-paragraphs:'+str(len(reps)))
  rows.append({'paper_id':d.name.split('--',1)[0],'total_chars':len(text),'issues':issues,'passed':not issues})
 out=Path(args.out) if args.out else root/'01-批次与审计/语义质量门禁.json'; out.write_text(json.dumps({'paper_count':len(rows),'passed':all(x['passed'] for x in rows),'rows':rows},ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); print(json.dumps({'passed':all(x['passed'] for x in rows),'paper_count':len(rows),'failed':sum(not x['passed'] for x in rows)},ensure_ascii=False)); return 0 if all(x['passed'] for x in rows) else 1
if __name__=='__main__': raise SystemExit(main())
