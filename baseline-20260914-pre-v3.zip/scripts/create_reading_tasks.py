#!/usr/bin/env python3
"""Create one auditable full-text reading task per paper directory.

The script never marks a task complete merely because a PDF exists. It emits
queue rows and per-paper task files, preserving existing task notes.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, re
from datetime import date
from pathlib import Path


def sha256(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()


def page_count(text: str) -> int:
    # Support the page marker emitted by the current extractor ("## PDF page N")
    # as well as the two legacy marker styles.
    nums = [int(x) for x in re.findall(r'(?mi)^\s*##\s+(?:PDF\s+)?page\s+(\d+)', text)]
    if nums:
        return max(nums)
    nums = [int(x) for x in re.findall(r'(?mi)^\s*---\s*page\s+(\d+)', text)]
    return max(nums) if nums else 0


def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--assigned-to',default='pending'); ap.add_argument('--integrator',default='pending'); ap.add_argument('--force',action='store_true'); args=ap.parse_args()
    root=Path(args.root).resolve(); papers=root/'04-论文深度阅读'; queue=root/'01-批次与审计/全文通读任务队列.csv'; task_dir=root/'01-批次与审计/reading-tasks'; task_dir.mkdir(parents=True,exist_ok=True)
    rows=[]
    for d in sorted(p for p in papers.iterdir() if p.is_dir()):
        parts=d.name.split('--',2); paper_id=parts[0]; year=parts[1] if len(parts)>1 else 'unknown'; slug=parts[2] if len(parts)>2 else d.name
        pdfs=list((root/'05-证据与原始材料/PDF').glob(f'{paper_id}--*.pdf'))
        texts=list((root/'05-证据与原始材料/全文提取').glob(f'{paper_id}--*.md'))
        pdf=pdfs[0] if pdfs else None; txt=texts[0] if texts else None
        task_id=f'READ-{paper_id}-v1'; task_path=task_dir/f'{task_id}.md'
        obj={'task_id':task_id,'paper_id':paper_id,'source_pdf':pdf.relative_to(root).as_posix() if pdf else None,'fulltext_path':txt.relative_to(root).as_posix() if txt else None,'pdf_hash':sha256(pdf) if pdf else None,'page_count':page_count(txt.read_text(encoding="utf-8",errors="replace")) if txt else 0,'version':year,'priority':'P0' if paper_id in {'P001','P002','P003','P009','P010'} else 'P1','reader_lane':'unassigned','assigned_to':args.assigned_to,'integrator':args.integrator,'status':'queued','stages':{'structure':'queued','theory':'queued','author_reasoning':'queued','method':'queued','experiments':'queued','figures_tables':'queued','conclusions_limits':'queued','synthesis':'queued'},'outputs':[],'blocking_reason':None,'review_status':'pending','created_at':date.today().isoformat()}
        if task_path.exists() and not args.force:
            old=task_path.read_text(encoding='utf-8',errors='replace')
            # Preserve either YAML-style status or the JSON object stored in
            # the task frontmatter; rebuilding the queue must not reset work.
            m=re.search(r'(?m)^status:\s*(\S+)',old)
            j=re.search(r'[\"\']status[\"\']\s*:\s*[\"\']([^\"\']+)',old)
            obj['status']=(m.group(1) if m else (j.group(1) if j else 'queued'))
        body='---\n'+json.dumps(obj,ensure_ascii=False,indent=2)+'\n---\n\n# 全文通读任务 '+paper_id+'\n\n## 阅读责任\n\n- 分配人：'+args.assigned_to+'\n- 全文整合负责人：'+args.integrator+'\n- 完成条件：见 `references/reading-task-contract.md`。\n\n## 阶段记录\n\n| 阶段 | 状态 | 产物 | 复核说明 |\n|---|---|---|---|\n| 结构 | queued |  |  |\n| 理论 | queued |  |  |\n| 作者思路 | queued |  |  |\n| 方法 | queued |  |  |\n| 实验 | queued |  |  |\n| 图表与公式 | queued |  |  |\n| 结论与局限 | queued |  |  |\n| 综合整合 | queued |  |  |\n\n## 阻塞与待核验\n\n- 暂无。\n'
        if not task_path.exists() or args.force: task_path.write_text(body,encoding='utf-8')
        rows.append({'task_id':task_id,'paper_id':paper_id,'source_pdf':obj['source_pdf'] or 'MISSING','fulltext_path':obj['fulltext_path'] or 'MISSING','pdf_hash':obj['pdf_hash'] or 'MISSING','page_count':obj['page_count'],'priority':obj['priority'],'reader_lane':obj['reader_lane'],'assigned_to':obj['assigned_to'],'integrator':obj['integrator'],'status':obj['status'],'review_status':obj['review_status'],'task_path':task_path.relative_to(root).as_posix()})
    with queue.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]) if rows else ['task_id']); w.writeheader(); w.writerows(rows)
    print(json.dumps({'paper_count':len(rows),'queue':queue.as_posix(),'task_dir':task_dir.as_posix()},ensure_ascii=False))
    return 0
if __name__=='__main__': raise SystemExit(main())
