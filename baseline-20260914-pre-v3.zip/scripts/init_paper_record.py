#!/usr/bin/env python3
"""Initialize Paper Record 2.0 with stable paper IDs and evidence-first layout."""
from __future__ import annotations
import argparse, json, re
from datetime import date
from pathlib import Path

DIRS=[
 '00-入口','01-批次与审计','02-论文索引','03-主题研究地图','04-论文深度阅读',
 '05-证据与原始材料/PDF','05-证据与原始材料/图表','05-证据与原始材料/数据与实验条件',
 '05-证据与原始材料/参考文献','05-证据与原始材料/全文提取','06-跨论文综合',
 '07-研究空白与机会','08-可复用科研资产','99-原始归档']

STARTERS={
 '00-入口/论文阅读总入口.md':'# 论文阅读总入口\n\n> 只放可读入口，不把目录当作链接目标。\n\n## 论文\n\n## 主题\n\n## 证据\n\n## 研究机会\n',
 '01-批次与审计/文件分类清单.md':'# 文件分类清单\n\n| 相对路径 | 业务分类 | 文件用途 | 关联对象 | 状态 | 批次ID |\n|---|---|---|---|---|---|\n',
 '01-批次与审计/全文任务队列.md':'# 全文任务队列\n\n| Task ID | Paper ID | Zotero Item | 结构 | 理论 | 方法 | 证据 | 综合 | 状态 | 产物 |\n|---|---|---:|---|---|---|---|---|---|---|\n',
 '02-论文索引/论文主索引.md':'# 论文主索引\n\n| Paper ID | 题名 | 年份 | 主题关系 | 全文状态 | 深度报告 | 证据审计 |\n|---|---|---:|---|---|---|---|\n',
 '03-主题研究地图/研究主题总图.md':'# 研究主题总图\n\n> 主题内容必须由逐篇全文报告和证据映射生成。\n',
 '06-跨论文综合/跨论文比较报告.md':'# 跨论文比较报告\n\n> 只有论文深读和材料审计完成后才能生成。\n',
 '07-研究空白与机会/研究空白总览.md':'# 研究空白总览\n\n> 每个空白必须有来源论文、证据、可检验问题和实验设计。\n',
 '08-可复用科研资产/可复用资产总览.md':'# 可复用资产总览\n\n> 每个资产必须有来源、变量、步骤、适用条件和复现状态。\n',
}

def register(root,p,cat,purpose,related,batch):
 ledger=root/'01-批次与审计/文件分类清单.md'
 if not ledger.exists(): return
 rel=p.relative_to(root).as_posix(); text=ledger.read_text(encoding='utf-8')
 if f'| {rel} |' not in text:
  with ledger.open('a',encoding='utf-8') as f:f.write(f'| {rel} | {cat} | {purpose} | {related} | 已生成 | {batch} |\n')

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--batch-id',default='PR-UNKNOWN'); args=ap.parse_args(); root=Path(args.root).resolve(); root.mkdir(parents=True,exist_ok=True); today=date.today().isoformat()
 for d in DIRS:(root/d).mkdir(parents=True,exist_ok=True)
 for rel,body in STARTERS.items():
  p=root/rel
  if not p.exists():
   p.write_text(body,encoding='utf-8'); register(root,p,'系统说明与入口','Paper Record 2.0 starter', 'unbound',args.batch_id)
 state={'schema_version':3,'skill':'papaer-record','batch_id':args.batch_id,'stage':0,'status':'not-started','created_at':today,'updated_at':today}
 p=root/'01-批次与审计/stage-state.json'; p.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); register(root,p,'系统说明与批次审计','阶段状态','batch',args.batch_id)
 print(root)
if __name__=='__main__': main()
