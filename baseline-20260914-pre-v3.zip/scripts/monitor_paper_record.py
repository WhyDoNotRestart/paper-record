#!/usr/bin/env python3
"""Continuously monitor Paper Record quality gates until the technical gates pass.

This is an observer: it never upgrades stage-state.json and never edits paper
content. It records each cycle so a human can distinguish transient failure from
completion. The process exits only when all configured technical gates pass, or
when --max-cycles is reached.
"""
from __future__ import annotations
import argparse, json, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path


def run(cmd: list[str], cwd: Path) -> dict:
    p=subprocess.run(cmd,cwd=cwd,text=True,encoding='utf-8',errors='replace',capture_output=True)
    return {'command':' '.join(cmd),'returncode':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip(),'passed':p.returncode==0}


def main() -> int:
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--interval',type=int,default=30); ap.add_argument('--max-cycles',type=int,default=0); ap.add_argument('--once',action='store_true'); ap.add_argument('--out'); args=ap.parse_args()
    root=Path(args.root).resolve(); repo=Path(__file__).resolve().parent
    work=root.parent.parent.parent.parent  # not relied upon for script location
    out=Path(args.out).resolve() if args.out else root/'01-批次与审计/monitor-status.jsonl'; out.parent.mkdir(parents=True,exist_ok=True)
    project=root.parents[3] if len(root.parents)>3 else Path.cwd()
    # The skill scripts are called by absolute path; cwd is the workspace containing the batch.
    workspace=Path.cwd()
    checks=[
      [sys.executable,'-X','utf8',str(repo/'check_reading_task_completion.py'),'--root',str(root)],
      [sys.executable,'-X','utf8',str(repo/'check_paper_reading_depth.py'),'--root',str(root)],
      [sys.executable,'-X','utf8',str(repo/'check_semantic_evidence.py'),'--root',str(root)],
      [sys.executable,'-X','utf8',str(repo/'check_matrix_field_richness.py'),'--root',str(root)],
      [sys.executable,'-X','utf8',str(repo/'check_genericity.py'),'--root',str(root)],
      [sys.executable,'-X','utf8',str(repo/'audit_material_usage.py'),'--root',str(root)],
      [sys.executable,'-X','utf8',str(repo/'check_filename_policy.py'),'--root',str(root)],
    ]
    cycle=0
    while True:
      cycle+=1; results=[run(c,workspace) for c in checks]
      status={'timestamp':datetime.now(timezone.utc).isoformat(),'cycle':cycle,'root':root.as_posix(),'passed':all(x['passed'] for x in results),'checks':results}
      with out.open('a',encoding='utf-8') as f:f.write(json.dumps(status,ensure_ascii=False)+'\n')
      print(json.dumps({'cycle':cycle,'passed':status['passed'],'failed':[x['command'] for x in results if not x['passed']]},ensure_ascii=False),flush=True)
      if status['passed'] or args.once or (args.max_cycles and cycle>=args.max_cycles): return 0 if status['passed'] else 1
      time.sleep(max(1,args.interval))

if __name__=='__main__': raise SystemExit(main())
