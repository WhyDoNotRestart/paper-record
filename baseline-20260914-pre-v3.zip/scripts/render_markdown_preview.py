#!/usr/bin/env python3
"""Generate a standalone Markdown smoke preview and validate its local assets."""
from __future__ import annotations
import argparse, html, json, re
from pathlib import Path
from urllib.parse import unquote

IMAGE = re.compile(r'!\[([^\]]*)\]\((<[^>]+>|[^)]+)\)')
LINK = re.compile(r'(?<!\!)\[([^\]]*)\]\((<[^>]+>|[^)]+)\)')
HEADING = re.compile(r'^(#{1,6})\s+(.+?)\s*$')


def clean(raw):
    raw = raw.strip()
    if raw.startswith('<') and raw.endswith('>'):
        raw = raw[1:-1]
    return raw.split('#', 1)[0].split('?', 1)[0]


def local_target(src, raw):
    target = clean(raw)
    if not target or target.startswith(('http://','https://','mailto:','data:','#')):
        return None
    p = Path(unquote(target)) if (target.startswith('/') or (len(target)>2 and target[1]==':')) else src.parent / unquote(target)
    return p.resolve()

def render_target(src, raw):
    # Preview files are written under the audit directory, not beside the source.
    # Use file:// URIs for local targets so the preview remains renderable after
    # opening it directly and does not create false broken links.
    p = local_target(src, raw)
    return p.as_uri() if p else raw


def inline(s, src, stats):
    chunks=[]; pos=0
    token=re.compile(r'!\[([^\]]*)\]\((<[^>]+>|[^)]+)\)|(?<!\!)\[([^\]]*)\]\((<[^>]+>|[^)]+)\)')
    for m in token.finditer(s):
        chunks.append(html.escape(s[pos:m.start()]))
        if m.group(1) is not None:
            alt, raw=m.group(1),m.group(2); p=local_target(src,raw); ok=bool(p and p.is_file()) or raw.startswith(('http://','https://','data:'))
            stats.append({'kind':'image','target':raw,'resolved':str(p) if p else raw,'exists':ok})
            chunks.append(f'<figure><img src="{html.escape(render_target(src, raw), quote=True)}" alt="{html.escape(alt, quote=True)}"><figcaption>{html.escape(alt)} — {"OK" if ok else "BROKEN"}</figcaption></figure>')
        else:
            label, raw=m.group(3),m.group(4); p=local_target(src,raw); ok=bool(p and (p.is_file() or p.is_dir())) or raw.startswith(('http://','https://','mailto:'))
            stats.append({'kind':'link','target':raw,'resolved':str(p) if p else raw,'exists':ok})
            chunks.append(f'<a href="{html.escape(render_target(src, raw), quote=True)}">{html.escape(label)}</a> <small class="status">— {"OK" if ok else "BROKEN"}</small>')
        pos=m.end()
    chunks.append(html.escape(s[pos:]))
    return ''.join(chunks)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--source',required=True); ap.add_argument('--out'); ap.add_argument('--report'); args=ap.parse_args()
    root=Path(args.root).resolve(); src=Path(args.source); src=(root/src).resolve() if not src.is_absolute() else src.resolve()
    if not src.is_file(): raise SystemExit(f'source not found: {src}')
    text=src.read_text(encoding='utf-8',errors='replace'); stats=[]; blocks=[]
    for line in text.splitlines():
        h=HEADING.match(line)
        if h: blocks.append(f'<h{len(h.group(1))}>{inline(h.group(2),src,stats)}</h{len(h.group(1))}>')
        elif line.strip(): blocks.append(f'<p>{inline(line,src,stats)}</p>')
    out=Path(args.out).resolve() if args.out else root/'01-批次与审计/preview.html'; out.parent.mkdir(parents=True,exist_ok=True)
    body=''.join(blocks)
    doc=f'<!doctype html><meta charset="utf-8"><title>{html.escape(src.name)}</title><style>body{{font:14px sans-serif;max-width:1000px;margin:2rem auto;line-height:1.65}}img{{max-width:100%;max-height:520px;object-fit:contain}}figure{{margin:1rem 0;padding:1rem;background:#f7f7f7}}.status{{color:#087f5b}}</style><h1>Preview: {html.escape(src.relative_to(root).as_posix())}</h1>{body}'
    out.write_text(doc,encoding='utf-8')
    bad=[x for x in stats if not x['exists']]
    report={'schema_version':2,'source':src.relative_to(root).as_posix(),'preview':out.relative_to(root).as_posix() if out.is_relative_to(root) else str(out),'target_count':len(stats),'image_count':sum(x['kind']=='image' for x in stats),'broken_count':len(bad),'passed':not bad,'targets':stats}
    if args.report:
        rp=Path(args.report); rp.parent.mkdir(parents=True,exist_ok=True); rp.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'source':report['source'],'preview':report['preview'],'target_count':report['target_count'],'broken_count':report['broken_count'],'passed':report['passed']},ensure_ascii=False))
    return 0 if report['passed'] else 1
if __name__=='__main__': raise SystemExit(main())
