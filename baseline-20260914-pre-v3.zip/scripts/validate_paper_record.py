#!/usr/bin/env python3
"""Structural validator for Paper Record outputs.

This checks layout and evidence-contract invariants only; it does not certify the
truth of paper content. Human acceptance remains mandatory.
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Dict, List

REQUIRED_DIRS = [
    "00-系统说明", "01-精华论文", "02-研究主题", "04-论文笔记",
    "99-佐证资料/图表与证据卡", "03-研究空白与可复用资产/概念与术语",
    "03-研究空白与可复用资产/研究空白", "03-研究空白与可复用资产/可复用科研资产",
    "99-佐证资料/参考文献", "09-模板", "99-佐证资料/原始论文", "99-待人工复核",
]
MATRIX_FIELDS = [
    "研究类型", "研究问题", "研究主题", "研究目的与核心问题", "研究对象与应用场景",
    "研究方法/技术路径", "数据与材料来源", "主要发现/关键结果", "创新点/贡献",
    "结论摘录", "实际意义/应用价值", "关键词标签", "文献图表", "图表说明解析论证",
]
PAPER_HEADINGS = [
    "研究类型", "研究问题", "研究主题", "研究目的与核心问题", "研究对象与应用场景",
    "研究方法/技术路径", "数据与材料来源", "主要发现/关键结果", "创新点/贡献",
    "结论摘录", "实际意义/应用价值", "关键词标签", "全文通读记录", "字段证据清单",
]
VALID_COMPLETION_LEVELS = {"framework", "abstract-level", "standard", "full-text-verified", "figure-only"}
VALID_EVIDENCE_SCOPES = {"zotero-metadata", "abstract", "publisher-page", "full-text", "figure-only"}
VALID_MATRIX_STATUS = {"provisional", "evidence-rich", "needs-review"}
VALID_READING_STATUS = {"queued", "reading", "synthesizing", "completed", "needs-review", "已收录"}


def rel(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def frontmatter(text: str) -> Dict[str, str]:
    if not text.startswith("---"):
        return {}
    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}
    result: Dict[str, str] = {}
    for line in parts[1].splitlines():
        match = re.match(r"^([A-Za-z_][A-Za-z0-9_-]*):\s*[\"']?([^\"']*)[\"']?\s*$", line.strip())
        if match:
            result[match.group(1)] = match.group(2).strip()
    return result


def embedded_targets(text: str) -> list[str]:
    return [m.group(1).split("|", 1)[0].strip() for m in re.finditer(r"!\[\[([^\]]+)\]\]", text)]


def target_exists(target: str, note: Path, root: Path) -> bool:
    target_path = Path(target)
    if target_path.is_absolute():
        return target_path.exists()
    return (note.parent / target_path).resolve().exists() or (root / target_path).resolve().exists()


def add_error(errors: List[dict], check_name: str, detail: str) -> None:
    errors.append({"check": check_name, "detail": detail, "status": "fail"})


def add_warning(warnings: List[dict], check_name: str, detail: str) -> None:
    warnings.append({"check": "warning:" + check_name, "detail": detail, "status": "warning"})


def check(condition: bool, name: str, detail: str, errors: List[dict], warnings: List[dict]) -> None:
    if not condition:
        add_error(errors, name, detail)


def workbook_headers(path: Path) -> list[set[str]]:
    try:
        from openpyxl import load_workbook
    except ImportError:
        return []
    headers: list[set[str]] = []
    workbook = load_workbook(path, read_only=True, data_only=False)
    try:
        for sheet in workbook.worksheets:
            for row in sheet.iter_rows(min_row=1, max_row=min(sheet.max_row, 10), values_only=True):
                values = {str(value).strip() for value in row if value not in (None, "")}
                if values:
                    headers.append(values)
    finally:
        workbook.close()
    return headers


def main() -> int:
    parser = argparse.ArgumentParser(description="验证Paper Record工作区结构与证据合同")
    parser.add_argument("--root", required=True, help="Vault或工作目录")
    parser.add_argument("--stage", type=int, choices=range(0, 8), default=0)
    args = parser.parse_args()

    root = Path(args.root).expanduser().resolve()
    errors: List[dict] = []
    warnings: List[dict] = []
    info: Dict[str, object] = {"root": str(root), "stage": args.stage}
    check(root.exists(), "root_exists", "目标目录存在", errors, warnings)
    if not root.exists():
        print(json.dumps({"passed": False, "errors": errors, "warnings": warnings}, ensure_ascii=False, indent=2))
        return 1

    nav = root / "00-论文阅读导航.md"
    aux = root / "00-其他资料索引.md"
    check(nav.exists(), "reading_navigation_exists", "根目录论文阅读导航存在", errors, warnings)
    check(aux.exists(), "auxiliary_index_exists", "根目录其他资料索引存在", errors, warnings)
    if nav.exists():
        nav_text = nav.read_text(encoding="utf-8", errors="replace")
        check(("论文总览" in nav_text or "精华论文总览" in nav_text) and ("进入论文" in nav_text or "阅读精华" in nav_text), "reading_navigation_contract", "阅读导航包含论文总览和直达入口", errors, warnings)

    missing_dirs = [d for d in REQUIRED_DIRS if not (root / d).is_dir()]
    check(not missing_dirs, "required_directories", "缺失：" + ", ".join(missing_dirs) if missing_dirs else "全部目录存在", errors, warnings)

    ledger = root / "00-系统说明" / "文件分类清单.md"
    check(ledger.exists(), "file_classification_manifest", "文件分类清单存在", errors, warnings)
    ledger_text = ledger.read_text(encoding="utf-8", errors="replace") if ledger.exists() else ""
    registered = set()
    for line in ledger_text.splitlines():
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if cells and cells[0] and cells[0] != "相对路径" and not set(cells[0]) <= {"-"}:
                registered.add(cells[0].replace("\\", "/"))
    all_files = [p for p in root.rglob("*") if p.is_file() and ".git" not in p.parts]
    info["file_count"] = len(all_files)
    unregistered = []
    for path in all_files:
        item = rel(path, root)
        if item == "00-系统说明/文件分类清单.md":
            continue
        if any(item.startswith(directory + "/") for directory in REQUIRED_DIRS) and item not in registered:
            unregistered.append(item)
    if unregistered:
        add_error(errors, "unregistered_files", "未在分类清单中出现：" + "; ".join(unregistered[:20]))

    queue = root / "00-系统说明" / "全文通读任务分配.md"
    if args.stage == 0:
        templates = [
            "09-模板/论文笔记模板.md", "09-模板/图表证据卡模板.md",
            "09-模板/分类小结模板.md", "00-系统说明/全文通读任务分配.md",
        ]
        missing = [item for item in templates if not (root / item).exists()]
        check(not missing, "starter_templates", "缺失：" + ", ".join(missing) if missing else "基础模板和全文队列模板存在", errors, warnings)

    if args.stage == 1:
        indexes = list((root / "01-精华论文").glob("*.md")) if (root / "01-精华论文").exists() else []
        real = []
        for path in indexes:
            rows = [line for line in path.read_text(encoding="utf-8", errors="replace").splitlines() if line.strip().startswith("|")]
            if len(rows) >= 3:
                real.append(path)
        info.update({"index_file_count": len(indexes), "real_index_file_count": len(real)})
        check(bool(real), "stage1_index", "已发现包含论文条目的分类索引文件" if real else "仅发现初始化索引模板，不能判定 Stage 1 完成", errors, warnings)

    if args.stage == 2:
        pdfs = list((root / "99-佐证资料/原始论文").rglob("*.pdf")) if (root / "99-佐证资料/原始论文").exists() else []
        failures = list((root / "99-待人工复核").glob("无法下载全文*.csv")) if (root / "99-待人工复核").exists() else []
        info["pdf_count"] = len(pdfs)
        invalid = []
        for pdf in pdfs:
            try:
                if pdf.read_bytes()[:5] != b"%PDF-":
                    invalid.append(rel(pdf, root))
            except OSError:
                invalid.append(rel(pdf, root) + " (无法读取)")
        check(not invalid, "pdf_signature", "PDF文件头有效" if not invalid else "无效PDF：" + "; ".join(invalid[:20]), errors, warnings)
        check(bool(pdfs or failures), "stage2_evidence", "已发现PDF或失败CSV" if (pdfs or failures) else "没有PDF或失败CSV，不能判定 Stage 2 完成", errors, warnings)
        check(queue.exists(), "reading_queue_exists", "全文通读任务分配表存在" if queue.exists() else "全文可用性确认后必须立即生成全文通读任务分配表", errors, warnings)
        if queue.exists():
            qtext = queue.read_text(encoding="utf-8", errors="replace")
            required = ["任务ID", "Zotero Item ID", "优先级", "reader_lane", "分配人", "状态", "证据覆盖率", "矩阵状态"]
            missing = [item for item in required if item not in qtext]
            check(not missing, "reading_queue_contract", "全文队列字段完整" if not missing else "缺少：" + ", ".join(missing), errors, warnings)

    if args.stage == 3:
        matrix_files = list(root.glob("*.xlsx")) + list((root / "01-精华论文").glob("*.xlsx")) if (root / "01-精华论文").exists() else list(root.glob("*.xlsx"))
        matrix_files = list(dict.fromkeys(matrix_files))
        check(bool(matrix_files), "stage3_matrix", "已发现矩阵/APA Excel" if matrix_files else "未发现矩阵/APA Excel", errors, warnings)
        info["matrix_file_count"] = len(matrix_files)
        try:
            from openpyxl import load_workbook  # noqa: F401
        except ImportError:
            add_warning(warnings, "excel_not_tested", "未安装 openpyxl，无法验证14字段表头")
        else:
            missing_headers = []
            for path in matrix_files:
                headers = workbook_headers(path)
                if headers and not any(set(MATRIX_FIELDS).issubset(header) for header in headers):
                    missing_headers.append(rel(path, root))
            if missing_headers:
                add_error(errors, "matrix_headers", "未发现包含完整14字段表头的工作表：" + "; ".join(missing_headers[:20]))

    if args.stage == 4:
        bibs = list((root / "99-佐证资料/参考文献").glob("*.bib")) if (root / "99-佐证资料/参考文献").exists() else []
        excels = list((root / "99-佐证资料/参考文献").glob("*.xlsx")) if (root / "99-佐证资料/参考文献").exists() else []
        check(bool(bibs or excels), "stage4_references", "已发现BibTeX/Excel参考文献文件" if (bibs or excels) else "未发现参考文献文件", errors, warnings)
        bad_bib = []
        for bib in bibs:
            text = bib.read_text(encoding="utf-8", errors="replace")
            if not re.search(r"(?m)^\s*@([A-Za-z]+)\s*\{", text) or text.count("{") != text.count("}"):
                bad_bib.append(rel(bib, root))
        check(not bad_bib, "bibtex_syntax", "BibTeX结构有效" if not bad_bib else "BibTeX结构异常：" + "; ".join(bad_bib[:20]), errors, warnings)

    if args.stage == 5:
        notes_dir = root / "04-论文笔记"
        notes = list(notes_dir.rglob("*.md")) if notes_dir.exists() else []
        notes = [path for path in notes if frontmatter(path.read_text(encoding="utf-8", errors="replace")).get("record_type") == "paper"]
        info["paper_note_count"] = len(notes)
        check(bool(notes), "stage5_paper_notes", "已发现论文主笔记" if notes else "未发现论文主笔记，不能判定全文深读完成", errors, warnings)
        check(queue.exists(), "stage5_reading_queue", "全文队列存在" if queue.exists() else "缺少全文通读任务分配表", errors, warnings)
        bad = []
        links = []
        for path in notes:
            text = path.read_text(encoding="utf-8", errors="replace")
            fm = frontmatter(text)
            missing_keys = [key for key in ("title", "zotero_item_id", "completion_level", "evidence_scope", "verification_status", "matrix_status", "field_evidence_coverage") if key not in fm]
            missing_headings = [heading for heading in PAPER_HEADINGS if not re.search(rf"(?m)^#{{2,3}}\s+(?:\d+\.\s*)?{re.escape(heading)}(?:$|\s)", text)]
            missing_fields = [f"F{i:02d}" for i in range(1, 13) if f"| F{i:02d} |" not in text]
            if missing_keys or missing_headings or missing_fields:
                detail = rel(path, root)
                if missing_keys: detail += " 缺少frontmatter=" + ",".join(missing_keys)
                if missing_headings: detail += " 缺少章节=" + ",".join(missing_headings)
                if missing_fields: detail += " 缺少证据字段=" + ",".join(missing_fields)
                bad.append(detail)
            if fm.get("completion_level") not in VALID_COMPLETION_LEVELS:
                bad.append(rel(path, root) + " completion_level非法")
            if fm.get("evidence_scope") not in VALID_EVIDENCE_SCOPES:
                bad.append(rel(path, root) + " evidence_scope非法")
            if fm.get("matrix_status") not in VALID_MATRIX_STATUS:
                bad.append(rel(path, root) + " matrix_status非法")
            coverage = fm.get("field_evidence_coverage", "")
            if fm.get("matrix_status") == "evidence-rich" and not re.fullmatch(r"100%|1(?:\.0+)?", coverage):
                bad.append(rel(path, root) + " evidence-rich但字段证据覆盖率不是100%")
            for target in embedded_targets(text):
                if not target_exists(target, path, root):
                    links.append(rel(path, root) + " -> " + target)
        check(not bad, "paper_note_contract", "论文主笔记字段/证据合同完整" if not bad else "；".join(bad[:20]), errors, warnings)
        check(not links, "paper_note_embeds", "嵌入链接可解析" if not links else "图表/附件链接不存在：" + "; ".join(links[:20]), errors, warnings)

    if args.stage == 6:
        card_dir = root / "99-佐证资料/图表与证据卡"
        all_cards = list(card_dir.rglob("*.md")) if card_dir.exists() else []
        cards = [path for path in all_cards if frontmatter(path.read_text(encoding="utf-8", errors="replace")).get("record_type") == "figure-evidence"]
        images = [path for path in card_dir.rglob("*") if path.suffix.lower() in {".png", ".jpg", ".jpeg", ".svg", ".pdf"}] if card_dir.exists() else []
        info.update({"figure_card_count": len(cards), "figure_asset_count": len(images)})
        check(bool(cards or images), "stage6_figure_assets", "已发现图表卡或素材" if (cards or images) else "未发现图表卡或图表素材", errors, warnings)
        bad = []
        links = []
        for path in cards:
            text = path.read_text(encoding="utf-8", errors="replace")
            fm = frontmatter(text)
            required = ["record_type", "paper_item_id", "figure_id", "source_page", "asset_type", "crop_status", "image_hash", "verification_status", "record_batch"]
            missing = [key for key in required if key not in fm]
            if missing:
                bad.append(rel(path, root) + " 缺少=" + ",".join(missing))
            for target in embedded_targets(text):
                if not target_exists(target, path, root):
                    links.append(rel(path, root) + " -> " + target)
        check(not bad, "figure_card_contract", "图表证据卡合同完整" if not bad else "；".join(bad[:20]), errors, warnings)
        check(not links, "figure_card_embeds", "图表嵌入链接可解析" if not links else "图表链接不存在：" + "; ".join(links[:20]), errors, warnings)
        if images and not cards:
            add_warning(warnings, "figure_without_card", "发现图表素材但没有图表证据卡")

    if args.stage == 7:
        notes_dir = root / "04-论文笔记"
        notes = list(notes_dir.rglob("*.md")) if notes_dir.exists() else []
        check(bool(notes), "stage7_inputs", "已有论文笔记可用于跨论文比较" if notes else "没有论文笔记，不能建立跨论文网络", errors, warnings)

    result = {"passed": not errors, "human_acceptance_required": True, "errors": errors, "warnings": warnings, "info": info}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())

